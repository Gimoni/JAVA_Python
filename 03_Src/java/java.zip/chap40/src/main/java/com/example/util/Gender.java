package com.example.util;

public enum Gender {
	M, F
}
