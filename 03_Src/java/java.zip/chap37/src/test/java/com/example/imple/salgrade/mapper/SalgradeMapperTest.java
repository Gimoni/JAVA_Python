package com.example.imple.salgrade.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.imple.emp.mapper.EmpMapper;

@SpringBootTest
public interface SalgradeMapperTest {

	


}
	
	

