package com.example.standard.util;

public enum IsOfficial {
	T, F
}
