package com.example.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Emp {
	int empno;
	String ename;
	String gender;
	String job;
	int mgr;
	int sal;
	int comm;
	int eptno;
}
