package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap33Application {

	public static void main(String[] args) {
		SpringApplication.run(Chap33Application.class, args);
	}

}
