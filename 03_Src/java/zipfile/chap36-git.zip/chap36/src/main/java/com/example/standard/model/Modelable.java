package com.example.standard.model;

public interface Modelable<T> {
	
	T getModel();
}
